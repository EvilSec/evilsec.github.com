#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

# Check if user is root
if [ $(id -u) != "0" ]; then
    echo "Error: You must be root to run this script, please use root to install LTPP"
    exit 1
fi

clear
echo "========================================================================="
echo "LTPP V1.4 for CentOS/RadHat Linux VPS  Written by Backtrace"
echo "========================================================================="
echo "A tool to auto-compile & install Tengine+Percona+PHP on Linux "
echo ""
echo "For more information please visit http://www.evilsec.com"
echo "========================================================================="
cur_dir=$(pwd)

#set main domain name

	domain="www.evilsec.com"
	echo "Please input domain:"
	read -p "(Default domain: www.evilsec.com):" domain
	if [ "$domain" = "" ]; then
		domain="www.evilsec.com"
	fi
	echo "==========================="
	echo domain="$domain"
	echo "==========================="

#set Server Administrator Email Address
	echo "==========================="
	ServerAdmin=""
	read -p "Please input Administrator Email Address:" ServerAdmin
	if [ "$ServerAdmin" == "" ]; then
		echo "Administrator Email Address will set to webmaster@example.com!"
		ServerAdmin="webmaster@example.com"
	else
	echo "==========================="
	echo Server Administrator Email="$ServerAdmin"
	echo "==========================="
	fi


#which version of php you want to install?
	echo "==========================="
	installphpver="5.2.17"
	echo "Which version of php you want to install?"
	echo "1 - php 5.2.17"
	echo "2 - php 5.3.23"
	echo "3 - php 5.4.13"
	read -p "(Default 5.2.17,if you want install 5.3.23 please input: 2 ,or you can input 3 to install 5.4.13):" installphpver

	case "$installphpver" in
	5.2|5.2.17|1)
	echo "You will install the php 5.2.17"
	installphpver="5.2.17"
	;;
	5.3|5.3.23|2)
	echo "You will install the php 5.3.23"
	installphpver="5.3.23"
	;;
	5.4|5.4.13|3)
	echo "You will install the php 5.4.13"
	installphpver="5.4.13"
	;;
	*)
	echo "INPUT error,you will install the php 5.2.17!"
	installphpver="5.2.17"
	esac

#do you want to install Database?
	echo "==========================="
	installdatabase="y"
	#echo "Do you want to install Database(MySQL or PostgreSQL)? You can install php without Database"
	echo "Do you want to install MySQL? You can install php without MySQL."
	read -p "(Default yes,if you want please press the enter button,if not please input: n ):" installdatabase

	case "$installdatabase" in
	y|Y|Yes|YES|yes|yES|yEs|YeS|yeS)
	echo "You will install the MySQL"
	installdatabase="y"
	;;
	n|N|No|NO|no|nO)
	echo "You will NOT install the MySQL!"
	installdatabase="n"
	;;
	*)
	echo "INPUT error,The MySQL will install!"
	installdatabase="y"
	esac

#check if install the Database
if [ $installdatabase = "y" ]; then

	#set mysql root password
	echo "==========================="
	mysqlrootpwd="root"
	echo "Please input the root password of mysql:"
	read -p "(Default password: root):" mysqlrootpwd
	if [ "$mysqlrootpwd" = "" ]; then
		mysqlrootpwd="root"
	fi
	echo "==========================="
	echo mysqlrootpwd="$mysqlrootpwd"
	echo "==========================="

	#do you want to install the InnoDB Storage Engine?
	echo "==========================="
	installinnodb="n"
	echo "Do you want to install the InnoDB Storage Engine?"
	read -p "(Default no,if you want please input: y ,if not please press the enter button):" installinnodb

	case "$installinnodb" in
	y|Y|Yes|YES|yes|yES|yEs|YeS|yeS)
	echo "You will install the InnoDB Storage Engine"
	installinnodb="y"
	;;
	n|N|No|NO|no|nO)
	echo "You will NOT install the InnoDB Storage Engine!"
	installinnodb="n"
	;;
	*)
	echo "INPUT error,The InnoDB Storage Engine will NOT install!"
	installinnodb="n"
	esac

	#do you want to install the HandlerSocket?
	echo "==========================="
	installhandlersocket="n"
	echo "Do you want to install the HandlerSocket?"
	read -p "(Default no,if you want please input: y ,if not please press the enter button):" installhandlersocket

	case "$installhandlersocket" in
	y|Y|Yes|YES|yes|yES|yEs|YeS|yeS)
	echo "You will install the HandlerSocket"
	installhandlersocket="y"
	;;
	n|N|No|NO|no|nO)
	echo "You will NOT install the HandlerSocket!"
	installhandlersocket="n"
	;;
	*)
	echo "INPUT error,The HandlerSocket will NOT install!"
	installhandlersocket="n"
	esac
fi

#do you want to install the Memcached?
	echo "==========================="
	installmemcache="y"
	echo "Do you want to install the Memcached?"
	read -p "(Default no,if you want please input: y ,if not please press the enter button):" installmemcache

	case "$installmemcache" in
	y|Y|Yes|YES|yes|yES|yEs|YeS|yeS)
	echo "You will install the Memcached"
	installmemcache="y"
	;;
	n|N|No|NO|no|nO)
	echo "You will NOT install the Memcached!"
	installmemcache="n"
	;;
	*)
	echo "INPUT error,The Memcached will NOT install!"
	installmemcache="n"
	esac

#do you want to install the ionCubed?
	echo "==========================="
	installioncube="n"
	echo "Do you want to install the ionCubed?"
	read -p "(Default no,if you want please input: y ,if not please press the enter button):" installioncube

	case "$installioncube" in
	y|Y|Yes|YES|yes|yES|yEs|YeS|yeS)
	echo "You will install the ionCubed"
	installioncube="y"
	;;
	n|N|No|NO|no|nO)
	echo "You will NOT install the ionCubed!"
	installioncube="n"
	;;
	*)
	echo "INPUT error,The ionCubed will NOT install!"
	installioncube="n"
	esac

	get_char()
	{
	SAVEDSTTY=`stty -g`
	stty -echo
	stty cbreak
	dd if=/dev/tty bs=1 count=1 2> /dev/null
	stty -raw
	stty echo
	stty $SAVEDSTTY
	}
	echo ""
	echo "Press any key to start..."
	char=`get_char`

rpm -qa|grep httpd
rpm -e httpd
rpm -qa|grep mysql
rpm -e mysql
rpm -qa|grep php
rpm -e php

#remove installed (apache php mysql)
yum -y remove httpd
yum -y remove php
yum -y remove mysql-server mysql
yum -y remove php-mysql

yum -y install yum-fastestmirror
yum -y remove httpd
yum -y update

#Set timezone
rm -rf /etc/localtime
ln -s /usr/share/zoneinfo/Asia/Shanghai /etc/localtime

yum install -y ntp
ntpdate -u pool.ntp.org
date

#Disable SeLinux
if [ -s /etc/selinux/config ]; then
sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config
/usr/sbin/setenforce 0
fi


#update all needed packages
for packages in patch make gcc gcc-c++ gcc-g77 flex bison file libtool libtool-libs autoconf kernel-devel libjpeg libjpeg-devel libpng libpng-devel libpng10 libpng10-devel gd gd-devel freetype freetype-devel libxml2 libxml2-devel zlib zlib-devel glib2 glib2-devel bzip2 bzip2-devel libevent libevent-devel ncurses ncurses-devel curl curl-devel e2fsprogs e2fsprogs-devel krb5 krb5-devel libidn libidn-devel openssl openssl-devel vim-minimal nano fonts-chinese gettext gettext-devel ncurses-devel gmp-devel pspell-devel unzip lynx libcap;
do yum -y install $packages; done

#if not install MySQL but want php support mysql connect
if [ $installdatabase = "n" ]; then
yum -y install mysql-connector-odbc mysql-devel libdbi-dbd-mysql
fi

echo "============================ check files ================================"

if [ -s gperftools-2.0.tar.gz ]; then
  echo "gperftools-2.0.tar.gz [found]"
  else
  echo "Error: gperftools-2.0.tar.gz not found!!!download now......"
  wget -c http://gperftools.googlecode.com/files/gperftools-2.0.tar.gz
fi

if [ -s php-5.2.17.tar.gz ]; then
  echo "php-5.2.17.tar.gz [found]"
  else
  echo "Error: php-5.2.17.tar.gz not found!!!download now......"
  wget -c http://us.php.net/get/php-5.2.17.tar.gz/from/this/mirror
fi

if [ -s re2c-0.13.5.tar.gz ]; then  
  echo "re2c-0.13.5.tar.gz [found]"  
  else  
  echo "Error: re2c-0.13.5.tar.gz not found!!!download now......"  
  wget -c http://ncu.dl.sourceforge.net/project/re2c/re2c/0.13.5/re2c-0.13.5.tar.gz  
fi 

if [ -s php-5.3.23.tar.gz ]; then
  echo "php-5.3.23.tar.gz [found]"
  else
  echo "Error: php-5.3.23.tar.gz not found!!!download now......"
  wget -c http://us.php.net/get/php-5.3.23.tar.gz/from/this/mirror
fi

if [ -s php-5.4.13.tar.gz ]; then
  echo "php-5.4.13.tar.gz [found]"
  else
  echo "Error: php-5.4.13.tar.gz not found!!!download now......"
  wget -c http://us.php.net/get/php-5.4.13.tar.gz/from/this/mirror
fi

if [ -s php-5.2.17-fpm-0.5.14.diff.gz ]; then
  echo "php-5.2.17-fpm-0.5.14.diff.gz [found]"
  else
  echo "Error: php-5.2.17-fpm-0.5.14.diff.gz not found!!!download now......"
  wget -c http://php-fpm.org/downloads/php-5.2.17-fpm-0.5.14.diff.gz
fi

if [ -s php-handelrsocket-0.3.1.tar.gz ]; then
  echo "php-handelrsocket-0.3.1.tar.gz [found]"
  else
  echo "Error: php-handelrsocket-0.3.1.tar.gz not found!!!download now......"
  wget -c http://php-handlersocket.googlecode.com/files/php-handelrsocket-0.3.1.tar.gz
fi

if [ -s memcached-1.4.15.tar.gz ]; then
  echo "memcached-1.4.15.tar.gz [found]"
  else
  echo "Error: memcached-1.4.15.tar.gz not found!!!download now......"
  wget -c http://memcached.googlecode.com/files/memcached-1.4.15.tar.gz
fi

if [ -s memcache-2.2.7.tgz ]; then
  echo "memcache-2.2.7.tgz [found]"
  else
  echo "Error: memcache-2.2.7.tgz not found!!!download now......"
  wget -c http://pecl.php.net/get/memcache-2.2.7.tgz
fi

if [ -s pcre-8.12.tar.gz ]; then
  echo "pcre-8.12.tar.gz [found]"
  else
  echo "Error: pcre-8.12.tar.gz not found!!!download now......"
  wget -c http://sourceforge.net/projects/pcre/files/pcre/8.12/pcre-8.12.tar.gz/download
fi

if [ -s tengine-1.4.4.tar.gz ]; then
  echo "tengine-1.4.4.tar.gz [found]"
  else
  echo "Error: tengine-1.4.4.tar.gz not found!!!download now......"
  wget -c http://tengine.taobao.org/download/tengine-1.4.4.tar.gz
fi

if [ -s Percona-Server-5.5.30-rel30.1.tar.gz ]; then
  echo "Percona-Server-5.5.30-rel30.1.tar.gz [found]"
  else
  echo "Error: Percona-Server-5.5.30-rel30.1.tar.gz not found!!!download now......"
  wget -c http://www.percona.com/downloads/Percona-Server-5.5/Percona-Server-5.5.30-30.1/source/Percona-Server-5.5.30-rel30.1.tar.gz
fi

if [ -s eaccelerator-0.9.5.3.tar.bz2 ]; then
  echo "eaccelerator-0.9.5.3.tar.bz2 [found]"
  else
  echo "Error: eaccelerator-0.9.5.3.tar.bz2 not found!!!download now......"
  wget -c http://pkgs.fedoraproject.org/repo/pkgs/php-eaccelerator/eaccelerator-0.9.5.3.tar.bz2/caf797223739516882f870342f74b935/eaccelerator-0.9.5.3.tar.bz2
fi

if [ -s libiconv-1.14.tar.gz ]; then
  echo "libiconv-1.14.tar.gz [found]"
  else
  echo "Error: libiconv-1.14.tar.gz not found!!!download now......"
  wget -c http://ftp.gnu.org/gnu/libiconv/libiconv-1.14.tar.gz
fi

if [ -s libmcrypt-2.5.8.tar.gz ]; then
  echo "libmcrypt-2.5.8.tar.gz [found]"
  else
  echo "Error: libmcrypt-2.5.8.tar.gz not found!!!download now......"
  wget -c  http://nchc.dl.sourceforge.net/project/mcrypt/Libmcrypt/2.5.8/libmcrypt-2.5.8.tar.gz
fi

if [ -s libevent-2.0.20-stable.tar.gz ]; then
  echo "libevent-2.0.20-stable.tar.gz [found]"
  else
  echo "Error: libevent-2.0.20-stable.tar.gz not found!!!download now......"
  wget -c http://cloud.github.com/downloads/libevent/libevent/libevent-2.0.20-stable.tar.gz
fi

if [ -s mhash-0.9.9.9.tar.gz ]; then
  echo "mhash-0.9.9.9.tar.gz [found]"
  else
  echo "Error: mhash-0.9.9.9.tar.gz not found!!!download now......"
  wget -c http://ncu.dl.sourceforge.net/project/mhash/mhash/0.9.9.9/mhash-0.9.9.9.tar.gz
fi

if [ -s mcrypt-2.6.8.tar.gz ]; then
  echo "mcrypt-2.6.8.tar.gz [found]"
  else
  echo "Error: mcrypt-2.6.8.tar.gz not found!!!download now......"
  wget -c http://nchc.dl.sourceforge.net/project/mcrypt/MCrypt/2.6.8/mcrypt-2.6.8.tar.gz
fi

if [ -s autoconf-2.13.tar.gz ]; then
  echo "autoconf-2.13.tar.gz [found]"
  else
  echo "Error: autoconf-2.13.tar.gz not found!!!download now......"
  wget -c http://ftp.gnu.org/gnu/autoconf/autoconf-2.13.tar.gz
fi
echo "======================== check files completed =========================="

echo "================== Install the necessary procedures ====================="
mkdir -p /home/wwwroot
chmod +w /home/wwwroot
mkdir -p /home/wwwlogs
chmod 777 /home/wwwlogs

cd $cur_dir

tar zxvf autoconf-2.13.tar.gz
cd autoconf-2.13/
./configure --prefix=/usr/local/webserver/autoconf-2.13
make && make install
cd ../

tar zxvf libiconv-1.14.tar.gz
cd libiconv-1.14/
./configure
make && make install
cd ../

cd $cur_dir
tar zxvf libmcrypt-2.5.8.tar.gz
cd libmcrypt-2.5.8/
./configure
make && make install
/sbin/ldconfig
cd libltdl/
./configure --enable-ltdl-install
make && make install
cd ../../

cd $cur_dir
tar zxvf mhash-0.9.9.9.tar.gz
cd mhash-0.9.9.9/
./configure
make && make install
cd ../

ln -s /usr/local/lib/libmcrypt.la /usr/lib/libmcrypt.la
ln -s /usr/local/lib/libmcrypt.so /usr/lib/libmcrypt.so
ln -s /usr/local/lib/libmcrypt.so.4 /usr/lib/libmcrypt.so.4
ln -s /usr/local/lib/libmcrypt.so.4.4.8 /usr/lib/libmcrypt.so.4.4.8
ln -s /usr/local/lib/libmhash.a /usr/lib/libmhash.a
ln -s /usr/local/lib/libmhash.la /usr/lib/libmhash.la
ln -s /usr/local/lib/libmhash.so /usr/lib/libmhash.so
ln -s /usr/local/lib/libmhash.so.2 /usr/lib/libmhash.so.2
ln -s /usr/local/lib/libmhash.so.2.0.1 /usr/lib/libmhash.so.2.0.1

cd $cur_dir
tar zxvf mcrypt-2.6.8.tar.gz
cd mcrypt-2.6.8/
./configure
make && make install
cd ../

if [ `getconf WORD_BIT` = '32' ] && [ `getconf LONG_BIT` = '64' ] ; then
        ln -s /usr/lib64/libpng.* /usr/lib/
        ln -s /usr/lib64/libjpeg.* /usr/lib/
fi

ulimit -v unlimited


if [ ! `grep -l "/lib"    '/etc/ld.so.conf'` ]; then
	echo "/lib" >> /etc/ld.so.conf
fi

if [ ! `grep -l '/usr/lib'    '/etc/ld.so.conf'` ]; then
	echo "/usr/lib" >> /etc/ld.so.conf
fi

if [ -d "/usr/lib64" ] && [ ! `grep -l '/usr/lib64'    '/etc/ld.so.conf'` ]; then
	echo "/usr/lib64" >> /etc/ld.so.conf
fi

if [ ! `grep -l '/usr/local/lib'    '/etc/ld.so.conf'` ]; then
	echo "/usr/local/lib" >> /etc/ld.so.conf
fi

ldconfig

cat >>/etc/security/limits.conf<<eof
* soft noproc 65535
* hard noproc 65535
* soft nofile 65535
* hard nofile 65535
eof

cat >>/etc/sysctl.conf<<eof
fs.file-max=65535
eof
echo "============= Install the necessary procedures completed ================"

if [ $installmemcache = "y" ]; then
echo "========================= memcached install ============================="
cd $cur_dir/
tar zxvf libevent-2.0.20-stable.tar.gz
cd libevent-2.0.20-stable/
./configure --prefix=/usr/local/webserver/libevent
make && make install
cd ../

echo "/usr/local/webserver/libevent/lib/" >> /etc/ld.so.conf
ln -s /usr/local/webserver/libevent/lib/libevent-2.0.so.5  /lib/libevent-2.0.so.5
ldconfig

tar zxvf memcached-1.4.15.tar.gz
cd memcached-1.4.15/
./configure --prefix=/usr/local/webserver/memcached
make && make install
cd ../

ln /usr/local/webserver/memcached/bin/memcached /usr/bin/memcached

cp conf/memcached-init /etc/init.d/memcached
chmod +x /etc/init.d/memcached
useradd -s /sbin/nologin nobody

chkconfig --level 345 memcached on

cp conf/memcache.php /home/wwwroot/memcache.php

echo "Starting Memcached..."
/etc/init.d/memcached start

#cd $cur_dir/
#tar zxvf libmemcached-1.0.10.tar.gz
#cd libmemcached-1.0.10
#./configure --prefix=/usr/local/webserver/libmemcached  --with-memcached
#make && make install

echo "===================== Install memcached completed ========-=============="
fi

echo "========================= gperftools install ============================"
cd $cur_dir

if [ `getconf WORD_BIT` = '32' ] && [ `getconf LONG_BIT` = '64' ] ; then
	if [ -s libunwind-0.99.tar.gz ]; then
		echo "libunwind-0.99.tar.gz [found]"
		else
		echo "Error: libunwind-0.99.tar.gz not found!!!download now......"
		wget -c http://mirror.yongbok.net/nongnu/libunwind/libunwind-0.99.tar.gz
	fi
	tar zxvf libunwind-0.99.tar.gz
	cd libunwind-0.99/
	CFLAGS=-fPIC ./configure
	make CFLAGS=-fPIC
	make CFLAGS=-fPIC install
	cd ../
fi

#TCMalloc install
tar zxvf gperftools-2.0.tar.gz
cd gperftools-2.0/
./configure
make && make install

echo "/usr/local/lib" >> /etc/ld.so.conf.d/usr_local_lib.conf
ldconfig
cd ../

mkdir /tmp/tcmalloc
chmod -R 777 /tmp/tcmalloc
echo "===================== Install gperftools completed ======================"

if [ $installdatabase = "y" ]; then
echo "=========================== MySQL install ==============================="
cd $cur_dir

mkdir -p /usr/local/webserver/mysql/conf
mkdir -p /usr/local/webserver/mysql/data
mkdir -p /usr/local/webserver/mysqldb

yum -y install cmake libaio-devel

tar zxvf Percona-Server-5.5.30-rel30.1.tar.gz
cd Percona-Server-5.5.30-rel30.1/
CC=gcc CFLAGS="-DBIG_JOINS=1 -DHAVE_DLOPEN=1 -O3" CXX=g++ CXXFLAGS="-DBIG_JOINS=1 -DHAVE_DLOPEN=1 -felide-constructors -fno-rtti -O3"

cd BUILD
./autorun.sh
cd ..
if [ $installinnodb = "y" ]; then
./configure --prefix=/usr/local/webserver/mysql --localstatedir=/usr/local/webserver/mysqldb --without-debug --with-extra-charsets=complex --enable-thread-safe-client --enable-assembler --with-mysqld-user=mysql --with-unix-socket-path=/tmp/mysql.sock --with-mysqld-ldflags=-all-static --with-client-ldflags=-all-static --with-charset=utf8 --with-extra-charsets=all --with-collation=utf8_general_ci --with-plugins=innobase,heap,partition,myisam --with-big-tables --enable-local-infile --with-server-suffix=-Percona-Server-Edition --with-mysqld-ldflags=-ltcmalloc_minimal
else
./configure --prefix=/usr/local/webserver/mysql --localstatedir=/usr/local/webserver/mysqldb --without-debug --with-extra-charsets=complex --enable-thread-safe-client --enable-assembler --with-mysqld-user=mysql --with-unix-socket-path=/tmp/mysql.sock --with-mysqld-ldflags=-all-static --with-client-ldflags=-all-static --with-charset=utf8 --with-extra-charsets=all --with-collation=utf8_general_ci --with-plugins=heap,partition,myisam --with-big-tables --enable-local-infile --with-server-suffix=-Percona-Server-Edition --with-mysqld-ldflags=-ltcmalloc_minimal
fi
make && make install
cd ../

sed -i 's@# executing mysqld_safe@# executing mysqld_safe\nexport LD_PRELOAD="/usr/local/lib/libtcmalloc.so"\n@' /usr/local/webserver/mysql/bin/mysqld_safe


#Add MySQL usergroup and config the access
groupadd mysql
useradd -s /sbin/nologin -M -g mysql mysql
ln -s /usr/local/webserver/mysql/lib/libmysqlclient.so.18 /usr/lib/

echo "copy mysql config file"
cp /usr/local/webserver/mysql/support-files/my-medium.cnf /etc/my.cnf
#sed -i 's/skip-locking/skip-external-locking/g' /etc/my.cnf

if [ $installinnodb = "y" ]; then
sed -i 's:#innodb:innodb:g' /etc/my.cnf
fi

mkdir /usr/local/webserver/mysqldb
chown mysql:mysql /usr/local/webserver/mysqldb
/usr/local/webserver/mysql/scripts/mysql_install_db --basedir=/usr/local/webserver/mysql --datadir=/usr/local/webserver/mysqldb --user=mysql

chown -R mysql /usr/local/webserver/mysqldb
chgrp -R mysql /usr/local/webserver/mysql/.

#replace basedir and datadir path in config file
sed -i 's#^basedir=$#basedir=/usr/local/webserver/mysql#g' /usr/local/webserver/mysql/support-files/mysql.server
sed -i 's#^datadir=$#datadir=/usr/local/webserver/mysqldb#g' /usr/local/webserver/mysql/support-files/mysql.server

cp /usr/local/webserver/mysql/support-files/mysql.server /etc/init.d/mysql
chmod 755 /etc/init.d/mysql

cat > /etc/ld.so.conf.d/mysql.conf<<EOF
/usr/local/webserver/mysql/lib/mysql
/usr/local/lib
EOF
ldconfig

ln -s /usr/local/webserver/mysql/lib/mysql /usr/lib/mysql
ln -s /usr/local/webserver/mysql/include/mysql /usr/include/mysql
/etc/init.d/mysql start

ln -s /usr/local/webserver/mysql/bin/mysql /usr/bin/mysql
ln -s /usr/local/webserver/mysql/bin/mysqldump /usr/bin/mysqldump
ln -s /usr/local/webserver/mysql/bin/myisamchk /usr/bin/myisamchk

/usr/local/webserver/mysql/bin/mysqladmin -u root password $mysqlrootpwd

cat > /tmp/mysql_sec_script<<EOF
use mysql;
update user set password=password('$mysqlrootpwd') where user='root';
delete from user where not (user='root') ;
delete from user where user='root' and password='';
drop database test;
DROP USER ''@'%';
flush privileges;
EOF

/usr/local/webserver/mysql/bin/mysql -u root -p$mysqlrootpwd -h localhost < /tmp/mysql_sec_script

rm -f /tmp/mysql_sec_script

/etc/init.d/mysql restart
/etc/init.d/mysql stop

cat >> /etc/my.cnf<<EOF

[mysqld]
log-slow-queries

EOF

echo "======================== MySQL install completed ========================"

if [ $installhandlersocket = "y" ]; then
echo "======================= HandlerSocket install ==========================="
cd $cur_dir
tar zxvf HandlerSocket-Plugin-for-MySQL.tar.gz
cd HandlerSocket-Plugin-for-MySQL
./autogen.sh
./configure --with-mysql-source=$cur_dir/Percona-Server-5.5.30-rel30.1/ --with-mysql-bindir=/usr/local/webserver/mysql/bin  --with-mysql-plugindir=/usr/local/webserver/mysql/lib/mysql/plugin
make && make install

cat >> /etc/my.cnf<<EOF
plugin-load=handlersocket.so

loose_handlersocket_port = 9998
# the port number to bind to (for read requests) 

loose_handlersocket_port_wr = 9999
# the port number to bind to (for write requests)

loose_handlersocket_threads = 16
# the number of worker threads (for read requests)

loose_handlersocket_threads_wr = 1
# the number of worker threads (for write requests)

open_files_limit = 65535
# to allow handlersocket accept many concurrent
# connections, make open_files_limit as large as
# possible.
EOF
echo "=================== HandlerSocket install completed ====================="
fi
fi

echo "========================== php+zend install ============================="
groupadd www
useradd -s /sbin/nologin -g www www

#set wwwroot's owner
chown -R www:www /home/wwwroot

if [ $installphpver = "5.2.17" ]; then
echo "You will install php 5.2.17"

cd $cur_dir
tar zxvf re2c-0.13.5.tar.gz
cd re2c-0.13.5
./configure
make
make install

cd $cur_dir
export PHP_AUTOCONF=/usr/local/webserver/autoconf-2.13/bin/autoconf
export PHP_AUTOHEADER=/usr/local/webserver/autoconf-2.13/bin/autoheader
tar zxvf php-5.2.17.tar.gz
gzip -cd php-5.2.17-fpm-0.5.14.diff.gz | patch -d php-5.2.17 -p1
cd php-5.2.17/
cp $cur_dir/php-5.2.17-max-input-vars.patch $cur_dir/php-5.2.17/php-5.2.17-max-input-vars.patch
patch -p1 < php-5.2.17-max-input-vars.patch
./buildconf --force

if [ $installdatabase = "n" ]; then
./configure --prefix=/usr/local/webserver/php --with-config-file-path=/usr/local/webserver/php/etc --with-iconv-dir --with-freetype-dir --with-jpeg-dir --with-png-dir --with-zlib --with-libxml-dir=/usr --enable-xml --disable-rpath --enable-discard-path --enable-magic-quotes --enable-safe-mode --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization --with-curl --with-curlwrappers --enable-mbregex --enable-fastcgi --enable-fpm --enable-force-cgi-redirect --enable-mbstring --with-mcrypt --enable-ftp --with-gd --enable-gd-native-ttf --with-openssl --with-mhash --enable-pcntl --enable-sockets --with-xmlrpc --enable-zip --enable-soap --without-pear --with-gettext --with-mime-magic
else
./configure --prefix=/usr/local/webserver/php --with-config-file-path=/usr/local/webserver/php/etc --with-mysql=/usr/local/webserver/mysql --with-mysqli=/usr/local/webserver/mysql/bin/mysql_config --with-iconv-dir --with-freetype-dir --with-jpeg-dir --with-png-dir --with-zlib --with-libxml-dir=/usr --enable-xml --disable-rpath --enable-discard-path --enable-magic-quotes --enable-safe-mode --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization --with-curl --with-curlwrappers --enable-mbregex --enable-fastcgi --enable-fpm --enable-force-cgi-redirect --enable-mbstring --with-mcrypt --enable-ftp --with-gd --enable-gd-native-ttf --with-openssl --with-mhash --enable-pcntl --enable-sockets --with-xmlrpc --enable-zip --enable-soap --without-pear --with-gettext --with-mime-magic
fi

make ZEND_EXTRA_LIBS='-liconv'
make install

mkdir -p /usr/local/webserver/php/etc
cp php.ini-dist /usr/local/webserver/php/etc/php.ini
cd ../

ln -s /usr/local/webserver/php/bin/php /usr/bin/php
ln -s /usr/local/webserver/php/bin/phpize /usr/bin/phpize
ln -s /usr/local/webserver/php/sbin/php-fpm /usr/bin/php-fpm

if [ $installmemcache = "y" ]; then
cd $cur_dir/
tar zxvf memcache-2.2.7.tgz
cd memcache-2.2.7/
/usr/local/webserver/php/bin/phpize
./configure --prefix=/usr/local/webserver/memcached --with-php-config=/usr/local/webserver/php/bin/php-config
make && make install
cd ../
fi

if [ $installdatabase = "y" ]; then
cd $cur_dir/php-5.2.17/ext/pdo_mysql/
/usr/local/webserver/php/bin/phpize
./configure --with-php-config=/usr/local/webserver/php/bin/php-config --with-pdo-mysql=/usr/local/webserver/mysql
make && make install
fi
cd $cur_dir/

if [ $installdatabase = "y" ]; then
if [ $installhandlersocket = "y" ]; then
tar zxvf php-handelrsocket-0.3.1.tar.gz
cd handlersocket
/usr/local/webserver/php/bin/phpize
./configure --with-php-config=/usr/local/webserver/php/bin/php-config
make
make install
cd ../
fi
fi

# php extensions
if [ $installmemcache = "y" ]; then
sed -i 's#extension_dir = "./"#extension_dir = "/usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20060613/"\nextension = "memcache.so"\nextension = "pdo_mysql.so"\nextension = "handlersocket.so"\n#' /usr/local/webserver/php/etc/php.ini
fi
sed -i 's#output_buffering = Off#output_buffering = On#' /usr/local/webserver/php/etc/php.ini
sed -i 's/post_max_size = 8M/post_max_size = 50M/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/upload_max_filesize = 2M/upload_max_filesize = 50M/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/;date.timezone =/date.timezone = PRC/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/short_open_tag = Off/short_open_tag = On/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/; cgi.fix_pathinfo=1/cgi.fix_pathinfo=0/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/; cgi.fix_pathinfo=0/cgi.fix_pathinfo=0/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/;cgi.fix_pathinfo=1/cgi.fix_pathinfo=0/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/register_long_arrays = On/;register_long_arrays = Off/g' /usr/local/webserver/php/etc/php.ini
#disable some dangerous functions
sed -i 's/disable_functions =.*/disable_functions = assert,escapeshellarg,escapeshellcmd,proc_close,proc_get_status,proc_open,proc_nice,proc_terminate,shell_exec,ini_restore,popen,dl,disk_free_space,diskfreespace,tmpfile,openlog,show_source,symlink,apache_child_terminate,apache_get_modules,apache_get_version,apache_getenv,apache_note,apache_setenv/g' /usr/local/webserver/php/etc/php.ini


#hidden php version output
sed -i 's/expose_php = On/expose_php = Off/g' /usr/local/webserver/php/etc/php.ini

sed -i 's/max_execution_time = 30/max_execution_time = 300/g' /usr/local/webserver/php/etc/php.ini

if [ `getconf WORD_BIT` = '32' ] && [ `getconf LONG_BIT` = '64' ] ; then
	#wget -c http://downloads.zend.com/optimizer/3.3.9/ZendOptimizer-3.3.9-linux-glibc23-x86_64.tar.gz
	tar zxvf ZendOptimizer-3.3.9-linux-glibc23-x86_64.tar.gz
	mkdir -p /usr/local/webserver/zend/
	cp ZendOptimizer-3.3.9-linux-glibc23-x86_64/data/5_2_x_comp/ZendOptimizer.so /usr/local/webserver/zend/
else
	#wget -c http://downloads.zend.com/optimizer/3.3.9/ZendOptimizer-3.3.9-linux-glibc23-i386.tar.gz
	tar zxvf ZendOptimizer-3.3.9-linux-glibc23-i386.tar.gz
	mkdir -p /usr/local/webserver/zend/
	cp ZendOptimizer-3.3.9-linux-glibc23-i386/data/5_2_x_comp/ZendOptimizer.so /usr/local/webserver/zend/
fi

cat >>/usr/local/webserver/php/etc/php.ini<<EOF
;eaccelerator

;ionCube

[Zend Optimizer] 
zend_optimizer.optimization_level=1 
zend_extension="/usr/local/webserver/zend/ZendOptimizer.so" 
EOF

rm -f /usr/local/webserver/php/etc/php-fpm.conf
cp conf/php-fpm.conf /usr/local/webserver/php/etc/php-fpm.conf

cp init.d.php-fpm5.2 /etc/init.d/php-fpm
chmod +x /etc/init.d/php-fpm

cd $cur_dir
if [ $installdatabase = "y" ]; then
	cp ltpp4php5.2 /root/ltpp
else
	cp ltpp4php5.2-nodatabase /root/ltpp
fi
chmod +x /root/ltpp



elif [ $installphpver = "5.3.23" ]; then
echo "You will install php 5.3.23"

cd $cur_dir
tar zxvf re2c-0.13.5.tar.gz
cd re2c-0.13.5
./configure
make
make install

cd $cur_dir
tar zxvf php-5.3.23.tar.gz
cd php-5.3.23/
./buildconf --force > testbuildconf
if grep -q "autoconf-2.13" testbuildconf; then 
	export PHP_AUTOCONF=/usr/local/webserver/autoconf-2.13/bin/autoconf
	export PHP_AUTOHEADER=/usr/local/webserver/autoconf-2.13/bin/autoheader
	./buildconf --force
else 
	echo "It looks like working.";
	cat testbuildconf
fi

if [ $installdatabase = "n" ]; then
./configure --prefix=/usr/local/webserver/php --with-config-file-path=/usr/local/webserver/php/etc --enable-fpm --with-fpm-user=www --with-fpm-group=www --with-mysql=mysqlnd --with-mysqli=mysqlnd --with-pdo-mysql=mysqlnd --with-iconv-dir --with-freetype-dir --with-jpeg-dir --with-png-dir --with-zlib --with-libxml-dir=/usr --enable-xml --disable-rpath --enable-magic-quotes --enable-safe-mode --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization --with-curl --with-curlwrappers --enable-mbregex --enable-mbstring --with-mcrypt --enable-ftp --with-gd --enable-gd-native-ttf --with-openssl --with-mhash --enable-pcntl --enable-sockets --with-xmlrpc --enable-zip --enable-soap --without-pear --with-gettext --disable-fileinfo --without-sqlite
else
./configure --prefix=/usr/local/webserver/php --with-config-file-path=/usr/local/webserver/php/etc --with-mysql=/usr/local/webserver/mysql --with-mysqli=/usr/local/webserver/mysql/bin/mysql_config --enable-fpm --with-fpm-user=www --with-fpm-group=www --with-mysql=mysqlnd --with-mysqli=mysqlnd --with-pdo-mysql=mysqlnd --with-iconv-dir --with-freetype-dir --with-jpeg-dir --with-png-dir --with-zlib --with-libxml-dir=/usr --enable-xml --disable-rpath --enable-magic-quotes --enable-safe-mode --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization --with-curl --with-curlwrappers --enable-mbregex --enable-mbstring --with-mcrypt --enable-ftp --with-gd --enable-gd-native-ttf --with-openssl --with-mhash --enable-pcntl --enable-sockets --with-xmlrpc --enable-zip --enable-soap --without-pear --with-gettext --disable-fileinfo --without-sqlite
fi

make ZEND_EXTRA_LIBS='-liconv'
make install

mkdir -p /usr/local/webserver/php/etc
cp php.ini-production /usr/local/webserver/php/etc/php.ini

ln -s /usr/local/webserver/php/bin/php /usr/bin/php
ln -s /usr/local/webserver/php/bin/phpize /usr/bin/phpize
ln -s /usr/local/webserver/php/sbin/php-fpm /usr/bin/php-fpm

if [ $installmemcache = "y" ]; then
cd $cur_dir/
tar zxvf memcache-2.2.7.tgz
cd memcache-2.2.7/
/usr/local/webserver/php/bin/phpize
./configure --prefix=/usr/local/webserver/memcached --with-php-config=/usr/local/webserver/php/bin/php-config
make && make install
cd ../
fi

if [ $installdatabase = "y" ]; then
cd $cur_dir/php-5.3.23/ext/pdo_mysql/
/usr/local/webserver/php/bin/phpize
./configure --with-php-config=/usr/local/webserver/php/bin/php-config --with-pdo-mysql=/usr/local/webserver/mysql
make && make install
fi
cd $cur_dir/

if [ $installdatabase = "y" ]; then
if [ $installhandlersocket = "y" ]; then
tar zxvf php-handelrsocket-0.3.1.tar.gz
cd handlersocket
/usr/local/webserver/php/bin/phpize
./configure --with-php-config=/usr/local/webserver/php/bin/php-config
make
make install
cd ../
fi
fi

# php extensions
sed -i 's#extension_dir = "./"#extension_dir = "/usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20090626/"\nextension = "memcache.so"\n#' /usr/local/webserver/php/etc/php.ini
sed -i 's/post_max_size = 8M/post_max_size = 50M/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/upload_max_filesize = 2M/upload_max_filesize = 50M/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/;date.timezone =/date.timezone = PRC/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/short_open_tag = Off/short_open_tag = On/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/; cgi.fix_pathinfo=1/cgi.fix_pathinfo=0/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/; cgi.fix_pathinfo=0/cgi.fix_pathinfo=0/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/;cgi.fix_pathinfo=1/cgi.fix_pathinfo=0/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/max_execution_time = 30/max_execution_time = 300/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/register_long_arrays = On/;register_long_arrays = Off/g' /usr/local/webserver/php/etc/php.ini
#sed -i 's/magic_quotes_gpc = On/;magic_quotes_gpc = Off/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/disable_functions =.*/disable_functions = assert,escapeshellarg,escapeshellcmd,proc_close,proc_get_status,proc_open,proc_nice,proc_terminate,shell_exec,ini_restore,popen,dl,disk_free_space,diskfreespace,tmpfile,openlog,show_source,symlink,apache_child_terminate,apache_get_modules,apache_get_version,apache_getenv,apache_note,apache_setenv/g' /usr/local/webserver/php/etc/php.ini

#hidden php version output
sed -i 's/expose_php = On/expose_php = Off/g' /usr/local/webserver/php/etc/php.ini

echo "Install ZendGuardLoader for PHP 5.3"
if [ `getconf WORD_BIT` = '32' ] && [ `getconf LONG_BIT` = '64' ] ; then
	#wget -c http://downloads.zend.com/guard/5.5.0/ZendGuardLoader-php-5.3-linux-glibc23-x86_64.tar.gz
	tar zxvf ZendGuardLoader-php-5.3-linux-glibc23-x86_64.tar.gz
	mkdir -p /usr/local/webserver/zend/
	cp ZendGuardLoader-php-5.3-linux-glibc23-x86_64/php-5.3.x/ZendGuardLoader.so /usr/local/webserver/zend/
else
	#wget -c http://downloads.zend.com/guard/5.5.0/ZendGuardLoader-php-5.3-linux-glibc23-i386.tar.gz
	tar zxvf ZendGuardLoader-php-5.3-linux-glibc23-i386.tar.gz
	mkdir -p /usr/local/webserver/zend/
	cp ZendGuardLoader-php-5.3-linux-glibc23-i386/php-5.3.x/ZendGuardLoader.so /usr/local/webserver/zend/
fi

echo "Write ZendGuardLoader to php.ini......"
cat >>/usr/local/webserver/php/etc/php.ini<<EOF
;eaccelerator

;ionCube

[Zend Optimizer] 
zend_extension=/usr/local/webserver/zend/ZendGuardLoader.so
EOF

echo "Creating new php-fpm configure file......"
cat >/usr/local/webserver/php/etc/php-fpm.conf<<EOF
[global]
pid = /usr/local/webserver/php/var/run/php-fpm.pid
error_log = /usr/local/webserver/php/var/log/php-fpm.log
log_level = notice

[www]
listen = /tmp/php-cgi.sock
user = www
group = www
pm = dynamic
pm.max_children = 20
pm.start_servers = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 3
EOF

echo "Copy php-fpm init.d file......"
#cp $cur_dir/php-5.3.23/sapi/fpm/init.d.php-fpm.in /etc/init.d/php-fpm
#cp $cur_dir/php-5.3.23/sapi/fpm/init.d.php-fpm /etc/init.d/php-fpm
cp $cur_dir/init.d.php-fpm5.3 /etc/init.d/php-fpm
chmod +x /etc/init.d/php-fpm

cd $cur_dir
if [ $installdatabase = "y" ]; then
	cp ltpp4php5.3 /root/ltpp
else
	cp ltpp4php5.3-nodatabase /root/ltpp
fi
chmod +x /root/ltpp



else
echo "You will install php 5.4.13"
cd $cur_dir
tar zxvf re2c-0.13.5.tar.gz
cd re2c-0.13.5
./configure
make
make install

cd $cur_dir
tar zxvf php-5.4.13.tar.gz
cd php-5.4.13/
./buildconf --force > testbuildconf
if grep -q "autoconf-2.13" testbuildconf; then 
	export PHP_AUTOCONF=/usr/local/webserver/autoconf-2.13/bin/autoconf
	export PHP_AUTOHEADER=/usr/local/webserver/autoconf-2.13/bin/autoheader
	./buildconf --force
else 
	echo "It looks like working.";
	cat testbuildconf
fi

if [ $installdatabase = "n" ]; then
./configure --prefix=/usr/local/webserver/php --with-config-file-path=/usr/local/webserver/php/etc --enable-fpm --with-fpm-user=www --with-fpm-group=www --with-mysql=mysqlnd --with-mysqli=mysqlnd --with-pdo-mysql=mysqlnd --with-iconv-dir --with-freetype-dir --with-jpeg-dir --with-png-dir --with-zlib --with-libxml-dir=/usr --enable-xml --disable-rpath --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization --with-curl --with-curlwrappers --enable-mbregex --enable-mbstring --with-mcrypt --enable-ftp --with-gd --enable-gd-native-ttf --with-openssl --with-mhash --enable-pcntl --enable-sockets --with-xmlrpc --enable-zip --enable-soap --without-pear --with-gettext --disable-fileinfo
else
./configure --prefix=/usr/local/webserver/php --with-config-file-path=/usr/local/webserver/php/etc --with-mysql=/usr/local/webserver/mysql --with-mysqli=/usr/local/webserver/mysql/bin/mysql_config --enable-fpm --with-fpm-user=www --with-fpm-group=www --with-mysql=mysqlnd --with-mysqli=mysqlnd --with-pdo-mysql=mysqlnd --with-iconv-dir --with-freetype-dir --with-jpeg-dir --with-png-dir --with-zlib --with-libxml-dir=/usr --enable-xml --disable-rpath --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization --with-curl --with-curlwrappers --enable-mbregex --enable-mbstring --with-mcrypt --enable-ftp --with-gd --enable-gd-native-ttf --with-openssl --with-mhash --enable-pcntl --enable-sockets --with-xmlrpc --enable-zip --enable-soap --without-pear --with-gettext --disable-fileinfo
fi
make ZEND_EXTRA_LIBS='-liconv'
make install

mkdir -p /usr/local/webserver/php/etc
cp php.ini-production /usr/local/webserver/php/etc/php.ini

#cp /usr/local/webserver/php/etc/php-fpm.conf.default /usr/local/webserver/php/etc/php-fpm.conf

ln -s /usr/local/webserver/php/bin/php /usr/bin/php
ln -s /usr/local/webserver/php/bin/phpize /usr/bin/phpize
ln -s /usr/local/webserver/php/sbin/php-fpm /usr/bin/php-fpm

if [ $installmemcache = "y" ]; then
cd $cur_dir/
tar zxvf memcache-2.2.7.tgz
cd memcache-2.2.7/
/usr/local/webserver/php/bin/phpize
./configure --prefix=/usr/local/webserver/memcached --with-php-config=/usr/local/webserver/php/bin/php-config
make && make install
cd ../
fi

if [ $installdatabase = "y" ]; then
cd $cur_dir/php-5.4.13/ext/pdo_mysql/
/usr/local/webserver/php/bin/phpize
./configure --with-php-config=/usr/local/webserver/php/bin/php-config --with-pdo-mysql=/usr/local/webserver/mysql
make && make install
fi
cd $cur_dir/

if [ $installdatabase = "y" ]; then
if [ $installhandlersocket = "y" ]; then
tar zxvf php-handelrsocket-0.3.1.tar.gz
cd handlersocket
/usr/local/webserver/php/bin/phpize
./configure --with-php-config=/usr/local/webserver/php/bin/php-config
make
make install
cd ../
fi
fi

# php extensions
sed -i 's#extension_dir = "./"#extension_dir = "/usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20090626/"\nextension = "memcache.so"\n#' /usr/local/webserver/php/etc/php.ini
sed -i 's/post_max_size = 8M/post_max_size = 50M/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/upload_max_filesize = 2M/upload_max_filesize = 50M/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/;date.timezone =/date.timezone = PRC/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/short_open_tag = Off/short_open_tag = On/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/; cgi.fix_pathinfo=1/cgi.fix_pathinfo=0/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/; cgi.fix_pathinfo=0/cgi.fix_pathinfo=0/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/;cgi.fix_pathinfo=1/cgi.fix_pathinfo=0/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/max_execution_time = 30/max_execution_time = 300/g' /usr/local/webserver/php/etc/php.ini
sed -i 's/disable_functions =.*/disable_functions = assert,escapeshellarg,escapeshellcmd,proc_close,proc_get_status,proc_open,proc_nice,proc_terminate,shell_exec,ini_restore,popen,dl,disk_free_space,diskfreespace,tmpfile,openlog,show_source,symlink,apache_child_terminate,apache_get_modules,apache_get_version,apache_getenv,apache_note,apache_setenv/g' /usr/local/webserver/php/etc/php.ini

#hidden php version output
sed -i 's/expose_php = On/expose_php = Off/g' /usr/local/webserver/php/etc/php.ini

echo "Write ZendGuardLoader to php.ini......"
cat >>/usr/local/webserver/php/etc/php.ini<<EOF
;eaccelerator

;ionCube

EOF

echo "Creating new php-fpm configure file......"
cat >/usr/local/webserver/php/etc/php-fpm.conf<<EOF
[global]
pid = /usr/local/webserver/php/var/run/php-fpm.pid
error_log = /usr/local/webserver/php/var/log/php-fpm.log
log_level = notice

[www]
listen = /tmp/php-cgi.sock
user = www
group = www
pm = dynamic
pm.max_children = 20
pm.start_servers = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 3
EOF

echo "Copy php-fpm init.d file......"
#cp $cur_dir/php-5.3.23/sapi/fpm/init.d.php-fpm.in /etc/init.d/php-fpm
#cp $cur_dir/php-5.3.23/sapi/fpm/init.d.php-fpm /etc/init.d/php-fpm
cp $cur_dir/init.d.php-fpm5.3 /etc/init.d/php-fpm
chmod +x /etc/init.d/php-fpm

cd $cur_dir
if [ $installdatabase = "y" ]; then
	cp ltpp4php5.3 /root/ltpp
else
	cp ltpp4php5.3-nodatabase /root/ltpp
fi
chmod +x /root/ltpp

fi

echo "====================== php+zend install completed ======================="

echo "=========================== Nginx install ==============================="
#nginx rewrite need pcre
cd $cur_dir
tar zxvf pcre-8.12.tar.gz
cd pcre-8.12/
./configure
make && make install
cd ../

tar zxvf tengine-1.4.4.tar.gz
cd tengine-1.4.4/
./configure --user=www --group=www --prefix=/usr/local/webserver/nginx --with-http_stub_status_module --with-http_ssl_module --with-http_gzip_static_module --with-ipv6 --with-google_perftools_module
make && make install
cd ../

rm -f /usr/local/webserver/nginx/conf/nginx.conf
cd $cur_dir

cp conf/nginx.conf /usr/local/webserver/nginx/conf/nginx.conf

cp conf/rewriteRules/dabr.conf /usr/local/webserver/nginx/conf/dabr.conf
cp conf/rewriteRules/discuz.conf /usr/local/webserver/nginx/conf/discuz.conf
cp conf/rewriteRules/sablog.conf /usr/local/webserver/nginx/conf/sablog.conf
cp conf/rewriteRules/typecho.conf /usr/local/webserver/nginx/conf/typecho.conf
cp conf/rewriteRules/wordpress.conf /usr/local/webserver/nginx/conf/wordpress.conf
cp conf/rewriteRules/discuzx.conf /usr/local/webserver/nginx/conf/discuzx.conf
cp conf/rewriteRules/none.conf /usr/local/webserver/nginx/conf/none.conf
cp conf/rewriteRules/wp2.conf /usr/local/webserver/nginx/conf/wp2.conf
cp conf/rewriteRules/interspire.conf /usr/local/webserver/nginx/conf/interspire.conf

sed -i 's/www.evilsec.com/'$domain'/g' /usr/local/webserver/nginx/conf/nginx.conf

rm -f /usr/local/webserver/nginx/conf/fcgi.conf
cp conf/fcgi.conf /usr/local/webserver/nginx/conf/fcgi.conf

cd $cur_dir
cp vhost.sh /root/vhost.sh
chmod +x /root/vhost.sh
#cp ltpp /root/
#chmod +x /root/ltpp
echo "====================== Nginx install completed =========================="

echo "=================== creat index page&phpinfo&Prober ====================="
#index.html
cp conf/index.html /home/wwwroot/index.html

#phpinfo
cat >/home/wwwroot/phpinfo.php<<eof
<?php
phpinfo();
?>
eof

#prober
cd $cur_dir
cp conf/p.php /home/wwwroot/p.php
echo "============== creat index page&phpinfo&Prober completed ================"

echo "========================= phpMyAdmin install ============================"
#phpmyadmin
tar zxvf pma.tar.gz
mv pma /home/wwwroot/phpmyadmin/
mkdir /home/wwwroot/phpmyadmin/upload/
mkdir /home/wwwroot/phpmyadmin/save/
chmod 755 -R /home/wwwroot/phpmyadmin/
chown www:www -R /home/wwwroot/phpmyadmin/
echo "================== phpMyAdmin install completed ========================="

echo "========================= add Nginx on startup =========================="
cp init.d.nginx /etc/init.d/nginx
chmod +x /etc/init.d/nginx

chkconfig --level 345 php-fpm on
chkconfig --level 345 nginx on
if [ $installdatabase = "y" ]; then
chkconfig --level 345 mysql on
fi
echo "=================== add Nginx on startup completed ======================"


echo "Starting LTPP..."
if [ $installdatabase = "y" ]; then
/etc/init.d/mysql start
fi
/etc/init.d/php-fpm start
/etc/init.d/nginx start

php_version=`php -r 'echo PHP_VERSION;'`

echo "========================= eaccelerator install =========================="

if [ -s /usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20060613/eaccelerator.so ]; then
rm -f /usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20060613/eaccelerator.so
elif [ -s /usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20090626/eaccelerator.so ]; then
rm -f /usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20090626/eaccelerator.so
elif [ -s /usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20100525/eaccelerator.so ]; then
rm -f /usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20100525/eaccelerator.so
fi

if [ $php_version = "5.2.14" ] || [ $php_version = "5.2.15" ] || [ $php_version = "5.2.16" ] || [ $php_version = "5.2.17" ] || [ $php_version = "5.2.17p1" ]; then

cd $cur_dir
tar jxvf eaccelerator-0.9.5.3.tar.bz2
cd eaccelerator-0.9.5.3/
/usr/local/webserver/php/bin/phpize
./configure --enable-eaccelerator=shared --with-php-config=/usr/local/webserver/php/bin/php-config --with-eaccelerator-shared-memory
make
make install
cd ../

mkdir -p /usr/local/webserver/eaccelerator_cache
sed -ni '1,/;eaccelerator/p;/;ionCube/,$ p' /usr/local/webserver/php/etc/php.ini

cat >ea.ini<<EOF
[eaccelerator]
zend_extension="/usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20060613/eaccelerator.so"
eaccelerator.shm_size="1"
eaccelerator.cache_dir="/usr/local/webserver/eaccelerator_cache"
eaccelerator.enable="1"
eaccelerator.optimizer="1"
eaccelerator.check_mtime="1"
eaccelerator.debug="0"
eaccelerator.filter=""
eaccelerator.shm_max="0"
eaccelerator.shm_ttl="3600"
eaccelerator.shm_prune_period="3600"
eaccelerator.shm_only="0"
eaccelerator.compress="1"
eaccelerator.compress_level="9"
eaccelerator.keys = "disk_only"
eaccelerator.sessions = "disk_only"
eaccelerator.content = "disk_only"

EOF

sed -i '/;eaccelerator/ {
r ea.ini
}' /usr/local/webserver/php/etc/php.ini

elif [ $php_version = "5.3.23" ]; then

cd $cur_dir
tar jxvf eaccelerator-0.9.6.1.tar.bz2
cd eaccelerator-0.9.6.1/
/usr/local/webserver/php/bin/phpize
./configure --enable-eaccelerator=shared --with-php-config=/usr/local/webserver/php/bin/php-config --with-eaccelerator-shared-memory
make
make install
cd ../

mkdir -p /usr/local/webserver/eaccelerator_cache
sed -ni '1,/;eaccelerator/p;/;ionCube/,$ p' /usr/local/webserver/php/etc/php.ini

cat >ea.ini<<EOF
[eaccelerator]
zend_extension="/usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20090626/eaccelerator.so"
eaccelerator.shm_size="1"
eaccelerator.cache_dir="/usr/local/webserver/eaccelerator_cache"
eaccelerator.enable="1"
eaccelerator.optimizer="1"
eaccelerator.check_mtime="1"
eaccelerator.debug="0"
eaccelerator.filter=""
eaccelerator.shm_max="0"
eaccelerator.shm_ttl="3600"
eaccelerator.shm_prune_period="3600"
eaccelerator.shm_only="0"
eaccelerator.compress="1"
eaccelerator.compress_level="9"
eaccelerator.keys = "disk_only"
eaccelerator.sessions = "disk_only"
eaccelerator.content = "disk_only"

EOF

sed -i '/;eaccelerator/ {
r ea.ini
}' /usr/local/webserver/php/etc/php.ini

elif [ $php_version = "5.4.13" ]; then

cd $cur_dir
tar zxvf eaccelerator-eaccelerator-42067ac.tar.gz
cd eaccelerator-eaccelerator-42067ac/
/usr/local/webserver/php/bin/phpize
./configure --enable-eaccelerator=shared --with-php-config=/usr/local/webserver/php/bin/php-config
make
make install
cd ../

mkdir -p /usr/local/webserver/eaccelerator_cache
sed -ni '1,/;eaccelerator/p;/;ionCube/,$ p' /usr/local/webserver/php/etc/php.ini

cat >ea.ini<<EOF
[eaccelerator]
zend_extension="/usr/local/webserver/php/lib/php/extensions/no-debug-non-zts-20100525/eaccelerator.so"
eaccelerator.shm_size="1"
eaccelerator.cache_dir="/usr/local/webserver/eaccelerator_cache"
eaccelerator.enable="1"
eaccelerator.optimizer="1"
eaccelerator.check_mtime="1"
eaccelerator.debug="0"
eaccelerator.filter=""
eaccelerator.shm_max="0"
eaccelerator.shm_ttl="3600"
eaccelerator.shm_prune_period="3600"
eaccelerator.shm_only="0"
eaccelerator.compress="1"
eaccelerator.compress_level="9"
eaccelerator.keys = "disk_only"
eaccelerator.sessions = "disk_only"
eaccelerator.content = "disk_only"

EOF

sed -i '/;eaccelerator/ {
r ea.ini
}' /usr/local/webserver/php/etc/php.ini
fi

rm ea.ini
echo "================== eaccelerator install completed ======================="

if [ $installioncube = "y" ]; then
echo "========================= ionCube install ==============================="
if [ `getconf WORD_BIT` = '32' ] && [ `getconf LONG_BIT` = '64' ] ; then
	cd /usr/local/webserver/
	#wget -c http://downloads2.ioncube.com/loader_downloads/ioncube_loaders_lin_x86-64.tar.gz
	cp $cur_dir/ioncube_loaders_lin_x86-64.tar.gz /usr/local/webserver/ioncube_loaders_lin_x86-64.tar.gz
	tar zxvf ioncube_loaders_lin_x86-64.tar.gz
else
	cd /usr/local/webserver/
	#wget -c http://downloads2.ioncube.com/loader_downloads/ioncube_loaders_lin_x86.tar.gz
	cp $cur_dir/ioncube_loaders_lin_x86.tar.gz /usr/local/webserver/ioncube_loaders_lin_x86.tar.gz
	tar zxvf ioncube_loaders_lin_x86.tar.gz
fi

sed -i '/ionCube Loader/d' /usr/local/webserver/php/etc/php.ini
sed -i '/ioncube_loader_lin/d' /usr/local/webserver/php/etc/php.ini

if [ $php_version = "5.2.14" ] || [ $php_version = "5.2.15" ] || [ $php_version = "5.2.16" ] || [ $php_version = "5.2.17" ] || [ $php_version = "5.2.17p1" ]; then
cat >ionCube.ini<<EOF
[ionCube Loader]
zend_extension="/usr/local/webserver/ioncube/ioncube_loader_lin_5.2.so"
EOF

sed -i '/;ionCube/ {
r ionCube.ini
}' /usr/local/webserver/php/etc/php.ini

elif [ $php_version = "5.3.23" ]; then
cat >ionCube.ini<<EOF
[ionCube Loader]
zend_extension="/usr/local/webserver/ioncube/ioncube_loader_lin_5.3.so"
EOF

sed -i '/;ionCube/ {
r ionCube.ini
}' /usr/local/webserver/php/etc/php.ini

fi

rm ionCube.ini
/etc/init.d/php-fpm restart
/etc/init.d/nginx restart
echo "===================== ionCube install completed ========================="
fi

echo "======================== some security config ==========================="
chown -R www:www /home/wwwroot

#add 80 port to iptables
if [ -s /sbin/iptables ]; then
/sbin/iptables -I INPUT -p tcp --dport 80 -j ACCEPT
/sbin/iptables-save
fi
echo "===================== some security config finished ====================="

echo "============================ Check install =============================="
clear
if [ -s /usr/local/webserver/nginx ]; then
  echo "/usr/local/webserver/nginx [found]"
  else
  echo "Error: /usr/local/webserver/nginx not found!!!"
fi

if [ -s /usr/local/webserver/php ]; then
  echo "/usr/local/webserver/php [found]"
  else
  echo "Error: /usr/local/webserver/php not found!!!"
fi

if [ $installdatabase = "y" ]; then
if [ -s /usr/local/webserver/mysql ]; then
  echo "/usr/local/webserver/mysql [found]"
  else
  echo "Error: /usr/local/webserver/mysql not found!!!"
fi
fi

echo "======================= Check install completed ========================="

if [ -s /usr/local/webserver/nginx ] && [ -s /usr/local/webserver/php ]; then

if [ $installdatabase = "y" ] && [ -s /usr/local/webserver/mysql ]; then
echo "Install LTPP V1.4 completed! enjoy it."
echo "========================================================================="
echo "LTPP V1.4 for CentOS/RadHat Linux VPS  Written by Backtrace "
echo "========================================================================="
echo ""
echo "For more information please visit http://www.evilsec.com/"
echo ""
echo "LTPP status manage: /root/ltpp {start|stop|reload|restart|kill|status}"
echo "default mysql root password:$mysqlrootpwd"
echo "default mysql root password:$mysqlrootpwd"
echo "phpinfo : http://$domain/phpinfo.php"
echo "Prober : http://$domain/p.php"
echo "Add VirtualHost : /root/vhost.sh"
echo ""
echo "The path of some dirs:"
echo "mysql dir:   /usr/local/webserver/mysql"
echo "php dir:     /usr/local/webserver/php"
echo "nginx dir:   /usr/local/webserver/nginx"
echo "web dir :    /home/wwwroot"
echo ""
elif [ $installdatabase = "n" ]; then
echo "Install LTPP V1.4 completed! enjoy it."
echo "========================================================================="
echo "LTPP V1.4 for CentOS/RadHat Linux VPS  Written by Backtrace "
echo "========================================================================="
echo ""
echo "For more information please visit http://www.evilsec.com/"
echo ""
echo "LTPP status manage: /root/ltpp {start|stop|reload|restart|kill|status}"
echo "phpinfo : http://$domain/phpinfo.php"
echo "Prober : http://$domain/p.php"
echo "Add VirtualHost : /root/vhost.sh"
echo ""
echo "The path of some dirs:"
echo "php dir:     /usr/local/webserver/php"
echo "nginx dir:   /usr/local/webserver/nginx"
echo "web dir :    /home/wwwroot"
echo ""
else
	echo "Sorry,Failed to install Percona Server!"
fi

echo "========================================================================="
/root/ltpp status
netstat -ntl
else
	echo "Sorry,Failed to install LTPP!"
	echo "Please visit http://www.evilsec.com/bugreport feedback errors and logs."
fi 